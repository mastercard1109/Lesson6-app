# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f162650603953938d332279c835407f68c2311481e895af8401cfe03993f8d0eff1bacd9eaf03bcdbcced50c3e9484975f8d79ee7bc1460ad1a4dd131d2cb4fd'